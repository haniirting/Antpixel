# Муравьиная империя AI — Android

Playable offline Android game prototype packaged in a native Android WebView. The game includes a premium dark-forest UI, 8×8 colored resource field, ant gathering orders, five visible queue slots, coins, nest upgrades, adaptive level difficulty, missions, an offline tactical advisor, and local save progress.

## Build APK

Requires JDK 17, Android SDK platform 35, and Gradle 8.9+ (the GitHub Actions workflow handles setup).

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk` (rename to `AntEmpireAI.apk` if desired).

## AI integration

The advisor currently works offline and provides rule-based strategy tips. To connect OpenRouter safely, configure a backend/server endpoint and store `OPENROUTER_API_KEY` as a server-side secret. Never put the private key in this APK or `index.html`.


## Real OpenRouter AI

The AI tab now supports (1) live analysis of the current colony and (2) AI-generated resource layouts. Deploy `backend/cloudflare-worker.js` as a Cloudflare Worker, store your key as the server-side secret `OPENROUTER_API_KEY`, then paste the Worker URL into the AI tab. Without a deployed endpoint the game falls back to offline hints. The key is never stored in the app. See `backend/README.md`.
