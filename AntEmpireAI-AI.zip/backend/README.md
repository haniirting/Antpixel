# Secure OpenRouter backend

The APK must never contain the private OpenRouter key. Deploy `cloudflare-worker.js` as a Cloudflare Worker. In Worker Settings -> Variables and Secrets, add **Secret** `OPENROUTER_API_KEY` with your OpenRouter key. Optional text variable: `OPENROUTER_MODEL` (default `openai/gpt-4o-mini`).

Copy the deployed Worker URL into the game's AI tab, e.g. `https://antempire-ai.<your-account>.workers.dev`. The endpoint supports `analyze` and `generate_level`.

For production, restrict CORS to your app/site origin and add rate limiting/authentication to avoid public abuse. Do not commit the key to GitHub or put it in the APK.
