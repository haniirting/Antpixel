// Cloudflare Worker backend for AntEmpireAI. Deploy as a Worker and set secret OPENROUTER_API_KEY.
// Optional variable OPENROUTER_MODEL, default: openai/gpt-4o-mini
const cors = {"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"POST, OPTIONS","Access-Control-Allow-Headers":"Content-Type"};
export default { async fetch(request, env) {
  if (request.method === "OPTIONS") return new Response(null,{headers:cors});
  if (request.method !== "POST") return Response.json({error:"POST only"},{status:405,headers:cors});
  if (!env.OPENROUTER_API_KEY) return Response.json({error:"Server secret OPENROUTER_API_KEY is missing"},{status:500,headers:cors});
  try {
    const body=await request.json(); const action=body.action; const game=body.game||{};
    const system = action === "generate_level"
      ? "You design balanced levels for a premium 2D ant-colony resource puzzle. Return ONLY valid JSON: {\"level\":{\"title\":string,\"tip\":string,\"counts\":{\"red\":integer,\"blue\":integer,\"yellow\":integer,\"purple\":integer,\"green\":integer,\"orange\":integer}}}. Counts should total 24-64; make level harder as level rises, distribute colors meaningfully, no extra keys. Do not invent game mechanics."
      : "You are the tactical AI advisor in a premium ant-colony resource puzzle. Analyze current game state and provide a concise, friendly Russian strategy: which color to collect first, how to use upgrades/coins, and one specific next move. Return ONLY JSON {\"analysis\":string}. Do not claim to see data not supplied.";
    const upstream=await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",headers:{"Authorization":"Bearer "+env.OPENROUTER_API_KEY,"Content-Type":"application/json","HTTP-Referer":"https://ant-colony-ai.higgsfield.app","X-Title":"Муравьиная империя AI"},body:JSON.stringify({model:env.OPENROUTER_MODEL||"openai/gpt-4o-mini",temperature:0.7,max_tokens:500,response_format:{type:"json_object"},messages:[{role:"system",content:system},{role:"user",content:JSON.stringify(game)}]})});
    const raw=await upstream.json(); if(!upstream.ok) return Response.json({error:raw.error?.message||"OpenRouter request failed"},{status:502,headers:cors});
    let content=raw.choices?.[0]?.message?.content||"{}"; let parsed=JSON.parse(content); return Response.json(parsed,{headers:{...cors,"Content-Type":"application/json"}});
  } catch(e) { return Response.json({error:String(e.message||e)},{status:500,headers:cors}); }
}};
