# AntEmpireAI — Android starter

This is a small native Android prototype for the Ant Empire AI color-clearing puzzle.

## Build an APK with GitHub Actions
1. Upload the contents of this folder to the root of your GitHub repository `AntEmpireAI`.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and press **Run workflow**, or push a commit to `main`.
4. Open the finished workflow run and download the artifact named `AntEmpireAI-debug-apk`.
5. The APK is inside the downloaded artifact as `app-debug.apk`.

This is a starter prototype, not yet a full port of the original web game. It has a 10×10 board, four colors, and clears every tile of the selected color.

## Requirements
- Android SDK 35 (the workflow installs it)
- Java 17
