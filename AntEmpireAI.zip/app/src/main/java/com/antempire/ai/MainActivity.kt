package com.antempire.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.widget.Toast
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var boardView: BoardView
    private lateinit var status: TextView
    private val palette = intArrayOf(
        Color.rgb(240, 84, 91),
        Color.rgb(65, 153, 238),
        Color.rgb(255, 190, 64),
        Color.rgb(80, 190, 123)
    )
    private val names = arrayOf("Красный", "Синий", "Жёлтый", "Зелёный")
    private var tiles = IntArray(100) { Random.nextInt(4) }
    private var moves = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(20, 26, 32))
        }
        val title = TextView(this).apply {
            text = "🐜 МУРАВЬИНАЯ ИМПЕРИЯ AI"
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = android.view.Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 64))
        status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 10, 0, 16)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 54))
        boardView = BoardView()
        root.addView(boardView, LinearLayout.LayoutParams(-1, 0, 1f))

        val help = TextView(this).apply {
            text = "Выбери цвет — исчезнут все клетки этого цвета"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        root.addView(help, LinearLayout.LayoutParams(-1, 50))

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
        }
        names.forEachIndexed { index, name ->
            val button = Button(this).apply {
                text = name
                textSize = 11f
                setTextColor(Color.WHITE)
                setBackgroundColor(palette[index])
                setOnClickListener { clearColor(index) }
            }
            buttons.addView(button, LinearLayout.LayoutParams(0, 52, 1f).apply {
                setMargins(3, 0, 3, 0)
            })
        }
        root.addView(buttons, LinearLayout.LayoutParams(-1, 60))
        val reset = Button(this).apply {
            text = "Новая партия"
            setOnClickListener {
                tiles = IntArray(100) { Random.nextInt(4) }
                moves = 0
                updateStatus()
                boardView.invalidate()
            }
        }
        root.addView(reset, LinearLayout.LayoutParams(-1, 52))
        setContentView(root)
        updateStatus()
    }

    private fun clearColor(color: Int) {
        val count = tiles.count { it == color }
        if (count == 0) {
            Toast.makeText(this, "Клеток этого цвета больше нет", Toast.LENGTH_SHORT).show()
            return
        }
        tiles = IntArray(tiles.size) { i -> if (tiles[i] == color) -1 else tiles[i] }
        moves++
        updateStatus()
        boardView.invalidate()
        if (tiles.all { it == -1 }) {
            Toast.makeText(this, "Победа! Все клетки очищены 🎉", Toast.LENGTH_LONG).show()
        }
    }

    private fun updateStatus() {
        val remaining = tiles.count { it >= 0 }
        status.text = "Ходы: $moves     Осталось клеток: $remaining"
    }

    private inner class BoardView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val antPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 24f
            textAlign = Paint.Align.CENTER
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cols = 10
            val rows = 10
            val cell = minOf(width.toFloat() / cols, height.toFloat() / rows)
            val left = (width - cell * cols) / 2f
            val top = (height - cell * rows) / 2f
            paint.color = Color.rgb(39, 48, 57)
            canvas.drawRoundRect(left - 5, top - 5, left + cell * cols + 5,
                top + cell * rows + 5, 18f, 18f, paint)
            for (i in tiles.indices) {
                val r = i / cols
                val c = i % cols
                val x = left + c * cell
                val y = top + r * cell
                if (tiles[i] < 0) {
                    paint.color = Color.rgb(29, 37, 44)
                } else {
                    paint.color = palette[tiles[i]]
                }
                canvas.drawRoundRect(x + 2, y + 2, x + cell - 2, y + cell - 2,
                    5f, 5f, paint)
            }
            // Decorative nest and ants in the center of the board.
            val cx = left + cell * 5
            val cy = top + cell * 5
            paint.color = Color.rgb(111, 78, 53)
            canvas.drawCircle(cx, cy, cell * 0.65f, paint)
            canvas.drawCircle(cx, cy, cell * 0.42f, paint)
            canvas.drawText("🐜", cx, cy + cell * 0.25f, antPaint)
        }
    }
}
